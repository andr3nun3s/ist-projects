/**/
#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <cstdlib>
#include "pacman.h"
#include "maze.h"
#include "ghost.h"
#include "particle.h"


#if defined (__APPLE__) || defined (MACOSX)
#include <OpenGL/OpenGL.h>
#include <GLUT/glut.h>
#else
#include <GL/glut.h>
#endif

/**********************************************************************
 **************************** GRUPO 2 *********************************
 **************** COMPUTAÇÃO GRÁFICA 2º SEMESTRE **********************
 ***************************2011/2012**********************************
 **********************************************************************/
#define SPEED 0.2
#define PI 3.141592653589793
#define RED 0.5f, 0.0f, 0.0f
#define GREEN 0.0f, 0.5f, 0.0f
#define BLUE 0.0f, 0.0f, 0.5f


float elapTime, difTime;
float prevTime = 0;
float ratio;
float movX = 0;
float movY = 0;
int cam = 1;
int score = 0000;

bool lightingEnabled = true;
bool keyPressed = false;
bool dayTime = true;
bool ghostwall = false;

 
maze *_maze = new maze(false);
maze *_ghostmaze = new maze(true);
pacman *_pacman = new pacman(0.0f, -2.0f);
ghost *_ghost0 = new ghost(2.5f, 1.0f);
ghost *_ghost1 = new ghost(2.5f, 1.0f);
ghost *_ghost2 = new ghost(2.5f, 1.0f);
pacman *_live1 = new pacman(-19.0f, 21.0f);
pacman *_live2 = new pacman(-17.0f, 21.0f);
pacman *_live3 = new pacman(-15.0f, 21.0f);
particle *_particle0 = new particle(0.0f, -2.0f, 0.0f, 0);
particle *_particle1 = new particle(0.0f, -2.0f, 0.0f, 1);
particle *_particle2 = new particle(0.0f, -2.0f, 0.0f, 2);
particle *_particle3 = new particle(0.0f, -2.0f, 0.0f, 3);
particle *_particle4 = new particle(0.0f, -2.0f, 0.0f, 4);
particle *_particle5 = new particle(0.0f, -2.0f, 0.0f, 5);
particle *_particle6 = new particle(0.0f, -2.0f, 0.0f, 6);
particle *_particle7 = new particle(0.0f, -2.0f, 0.0f, 7);
particle *_particle8 = new particle(0.0f, -2.0f, 0.0f, 8);
particle *_particle9 = new particle(0.0f, -2.0f, 0.0f, 9);


float round(float f)
{
	if(f < 0){
		return ((floor(f*-1 + 0.5))*-1);}
	else
		return floor(f + 0.5);
}

std::string inttostr(int number)
{
    if (number == 0)
        return "0";
    std::string temp="";
    std::string returnvalue="";
    while (number>0)
    {
        temp+=number%10+48;
        number/=10;
    }
    for (unsigned int i=0;i<temp.length();i++)
        returnvalue+=temp[temp.length()-i-1];
    return returnvalue;
}

bool collision(pacman *p, ghost *g){
	if( ((p->getX() - g->getX()) <= 0.25f)  && 
		((p->getX() - g->getX()) >= -0.25f) &&
		((p->getY() - g->getY()) <= 0.25f) &&
		((p->getY() - g->getY()) >= -0.25f))
			return true;
	else
			return false;
}		
		

//Called when a key is pressed
void handleKeypress(unsigned char key, int x, int y) {

	if  (key == 27 || key == 'q') { //escape or Q key
    exit(0); //Quit program 
	}

	if(key == 'w' || key == 'W'){
		if(!(_maze->isWall(round(_pacman->getX()), round(_pacman->getY() + 1))) ||
			!(_maze->isWall(round(_pacman->getX()) + _pacman->getVX(), round(_pacman->getY() + 1))) ||
			!(_maze->isWall(round(_pacman->getX()) + 3*_pacman->getVX(), round(_pacman->getY() + 1))) ||
			!(_maze->isWall(round(_pacman->getX()) + 2*_pacman->getVX(), round(_pacman->getY() + 1)))){
				movX = 0;
				movY = 1;
				keyPressed = true;
		}
	} 
	if(key == 's' || key == 'S'){
		if(!(_maze->isWall(round(_pacman->getX()), round(_pacman->getY() - 1))) ||
			!(_maze->isWall(round(_pacman->getX()) + _pacman->getVX(), round(_pacman->getY() - 1))) ||
			!(_maze->isWall(round(_pacman->getX()) + 3*_pacman->getVX(), round(_pacman->getY() - 1))) ||
			!(_maze->isWall(round(_pacman->getX()) + 2*_pacman->getVX(), round(_pacman->getY() - 1)))){
				movX = 0;
				movY = -1;
				keyPressed = true;
		}
	} 
	if(key == 'a' || key == 'A'){
		if(!(_maze->isWall(round(_pacman->getX()) - 1, round(_pacman->getY()))) ||
			!(_maze->isWall(round(_pacman->getX()) - 1, round(_pacman->getY() + _pacman->getVY()))) ||
			!(_maze->isWall(round(_pacman->getX()) - 1, round(_pacman->getY() + 3*_pacman->getVY()))) ||
			!(_maze->isWall(round(_pacman->getX()) - 1, round(_pacman->getY() + 2*_pacman->getVY())))){
				movX = -1;
				movY = 0;
				keyPressed = true;
		}
	} 
	if(key == 'd' || key == 'D'){
		if(!(_maze->isWall(round(_pacman->getX()) + 1, round(_pacman->getY()))) ||
			!(_maze->isWall(round(_pacman->getX()) + 1, round(_pacman->getY() + _pacman->getVY()))) ||
			!(_maze->isWall(round(_pacman->getX()) + 1, round(_pacman->getY() + 3*_pacman->getVY()))) ||
			!(_maze->isWall(round(_pacman->getX()) + 1, round(_pacman->getY() + 2*_pacman->getVY())))){
				movX = 1;
				movY = 0;
				keyPressed = true;
		}
	}
	if(key == '1'){
		cam = 1;
	}

	if(key == '2'){
		cam = 2;
	}
	
	if(key == 'i' || key == 'I'){		//debug
		lightingEnabled = !lightingEnabled;
		if (!lightingEnabled == false)
			glEnable(GL_LIGHTING);
		else
			glDisable(GL_LIGHTING);
	}

	if(key == 'n' || key == 'N'){
		if (dayTime){
			glDisable(GL_LIGHT0);
			glEnable(GL_LIGHT1);
			dayTime = false;
			_pacman->setRadioactive(true);
			_particle0->setRadioactive(true);
			_particle1->setRadioactive(true);
			_particle2->setRadioactive(true);
			_particle3->setRadioactive(true);
			_particle4->setRadioactive(true);
			_particle5->setRadioactive(true);
			_particle6->setRadioactive(true);
			_particle7->setRadioactive(true);
			_particle8->setRadioactive(true);
			_particle9->setRadioactive(true);
			
			
		}
		else{
			glDisable(GL_LIGHT1);
			glEnable(GL_LIGHT0);
			dayTime = true;
			_pacman->setRadioactive(false);
		}
	}


	if(key == '6'){		//debug
		float x = _pacman->getX();
		float y = _pacman->getY();
		float angle = _pacman->getAngle();
		std::cout << "Num balls: " << _maze->getBalls() << std::endl;
		std::cout << x << " " << y << " " << angle << std::endl << _maze->getMazeInfo(x, y) << std::endl;
	}
	
	if(key == 'b' || key == 'B'){ //debug
		
		for(int j = 38; j >=0 ; j--){
			for(int i = 0; i <= 38; i++){
				std::cout << _maze->getBluePrint(i, j) << " ";
			}
			std::cout << std::endl;
		}
		std::cout << std::endl;
	}
	
	if(key == 'v' || key == 'V'){ //debug
		
		for(int j = 38; j >= 0; j--){
			for(int i = 0; i <= 38; i++){
				std::cout << _ghostmaze->getBluePrint(i, j) << " ";
			}
			std::cout << std::endl;
		}
		std::cout << std::endl;
	}

	if(key == 'p' || key == 'P'){ //debug
	std::cout << _pacman->getX() << " " << _pacman->getY() << std::endl;
	std::cout << _pacman->getVX() << " " << _pacman->getVY() << std::endl;
	}

	if(key == 'f' || key == 'F'){ //debug
		std::cout << _ghost0->getX() << " " << _ghost0->getY() << std::endl;
		std::cout << _ghost0->getVX() << " " << _ghost0->getVY() << std::endl;
	}

	if(key == 'r' || key == 'R'){ //debug
		std::cout << collision(_pacman, _ghost0) << std::endl;
		std::cout << collision(_pacman, _ghost1) << std::endl;
		std::cout << collision(_pacman, _ghost2) << std::endl;
	}
}

void initRendering() {
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_NORMALIZE);
	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);
	
}

void drawScore(){

	int x = 16;
	
	std::string points = "0000";

	
		points.insert(0, inttostr((score/1000)%10));		
		points.insert(1, inttostr((score/100)%10));
		points.insert(2, inttostr((score/10)%10));
		points.insert(3, inttostr(score%10));
	
	
		

	for (int i = 0; i < 4; i++){ 
		char c = points[i];
		glRasterPos3f(x, 20.7f, 2.0f);
		glutBitmapCharacter(GLUT_BITMAP_9_BY_15, c);
		x += 1;
	}

}

void hud(){
	glColor3f(0.8, 0.8, 0.0);
	glRasterPos3f(12.0f, 20.7f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, 'S');
	glRasterPos3f(12.5f, 20.7f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, 'c');
	glRasterPos3f(13.0f, 20.7f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, 'o');
	glRasterPos3f(13.5f, 20.7f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, 'r');
	glRasterPos3f(14.0f, 20.7f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, 'e');
	glRasterPos3f(14.5f, 20.7f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_9_BY_15, ':');
}

void drawGameOver(){
	glPushMatrix();
	glColor3f(0.8, 0.0, 0.0);
	glScalef(3.0f, 3.0f, 3.0f);
	glRasterPos3f(-2.0f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'G');
	glRasterPos3f(-1.5f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'a');
	glRasterPos3f(-1.0f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'm');
	glRasterPos3f(-0.5f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'e');
	glRasterPos3f(0.0f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, ' ');
	glRasterPos3f(0.5f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'O');
	glRasterPos3f(1.0f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'v');
	glRasterPos3f(1.5f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'e');
	glRasterPos3f(2.0f, 0.0f, 2.0f);
	glutBitmapCharacter(GLUT_BITMAP_HELVETICA_18, 'r');
	glPopMatrix();
}

//Called when the window is resized
void handleResize(int w, int h) {
	glViewport(0, 0, w, h);
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();


	if(cam == 1){
		if(w < h){
			ratio = (float) h/ (float) w;
			std::cout << ratio << "\n";
			std::cout << "TALL1.0\n";
			glOrtho(-20.0f, 20.0f, -20.0f*ratio, 20.0f*ratio, -20.f, 20.f);
		}
		else{
			ratio = (float) w/ (float) h;
			std::cout << ratio << "\n";
			std::cout << "FAT1.0\n";
			glOrtho(-20.0f*ratio, 20.0f*ratio, -20.0f, 20.0f, -20.f, 20.f);
		}
	}

	if(cam == 2){
		if(w < h){
			ratio = (float) h/ (float) w;
			std::cout << ratio << "\n";
			std::cout << "TALL2\n";
			gluPerspective(90, ratio, 1, 10);
		}
		else{
			ratio = (float) w/ (float) h;
			std::cout << ratio << "\n";
			std::cout << "FAT2\n";
			gluPerspective(90, ratio, 1, 10);
		}
	}
}

void handleCamera(/*float minWidthOrtho, float maxWidthOrtho,
				  float minHeightOrtho, float maxHeightOrtho*/){
	
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	float w = glutGet(GLUT_WINDOW_WIDTH);
	float h = glutGet(GLUT_WINDOW_HEIGHT);

	glDisable(GL_LIGHTING);

	if(w < h){
		ratio = (float) h/ (float) w;
		glOrtho(-20.0f, 20.0f, -20.0f*ratio, 22.0f*ratio, -20.f, 20.f);
	}
	else{
		ratio = (float) w/ (float) h;
		glOrtho(-20.0f*ratio, 20.0f*ratio, -20.0f, 22.0f, -20.f, 20.f);
	}

	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	hud();
	drawScore();
	if(_pacman->getDead())
		drawGameOver();
	int lives = _pacman->getLives();
	if(lives == 3){
		_live1->drawPacman(-19.0f, 21.0f);
		_live2->drawPacman(-17.0f, 21.0f);
		_live3->drawPacman(-15.0f, 21.0f);}
	else if(lives == 2){
		_live1->drawPacman(-19.0f, 21.0f);
		_live2->drawPacman(-17.0f, 21.0f);}
	else if(lives == 1)
		_live1->drawPacman(-19.0f, 21.0f);
	else if(lives == 0)
		drawGameOver();

	glEnable(GL_LIGHTING);

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	
	if(cam == 1){
		if(w < h){
			ratio = (float) h/ (float) w;
			glOrtho(-20.0f, 20.0f, -20.0f*ratio, 22.0f*ratio, -20.f, 20.f);
		}
		else{
			ratio = (float) w/ (float) h;
			glOrtho(-20.0f*ratio, 20.0f*ratio, -20.0f, 22.0f, -20.f, 20.f);
		}
	}
	
	if(cam == 2){
		if(w < h){
			ratio = (float) h/ (float) w;
			gluPerspective(90, ratio, 1, 100);
		}
		else{
			ratio = (float) w/ (float) h;
			gluPerspective(90, ratio, 1, 100);
		}
	}
		
		
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	GLfloat light_diffuse[]  = {1.0f, 1.0f, 1.0f, 1.0f};
	GLfloat light_specular[]  = {1.0f, 1.0f, 1.0f, 1.0f};
	GLfloat light_ambient[]  = {0.0f, 0.0f, 0.0f, 1.0f};
	glLightfv(GL_LIGHT0, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT0, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, light_diffuse);
	glLightfv(GL_LIGHT1, GL_SPECULAR, light_specular);
	glLightfv(GL_LIGHT1, GL_AMBIENT, light_ambient);
	glLightfv(GL_LIGHT1, GL_DIFFUSE, light_diffuse);

	if(cam == 2){
		float x = _pacman->getX();
		float y = _pacman->getY();
		gluLookAt(x+1, y-3,5, x, y, 0, 0.05, 0 ,0.9);
	}

	
	GLfloat light0_position[] = {0.5, -0.5, 1.0, 0.0 };
	GLfloat light1_position[] = {_pacman->getX(), _pacman->getY(), 1.5, 1.0 };
	GLfloat light1_direction1[] = {_pacman->getVX(), _pacman->getVY(), -0.5};	
	glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
	glLightfv(GL_LIGHT1, GL_POSITION, light1_position);
    if(_pacman->getVX() == 0.0f && _pacman->getVY() == 0.0f){}
    else
	glLightfv(GL_LIGHT1, GL_SPOT_DIRECTION, light1_direction1);
    	glLightf(GL_LIGHT1, GL_SPOT_CUTOFF, 30);
    	glLightf(GL_LIGHT1, GL_SPOT_EXPONENT, 0);	
}

//Draws the 3D scene
void myDisplay(){
	glClearColor(0.0f,0.0f,0.0f,0.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	
	handleCamera();

	_maze->drawMaze();
	_pacman->drawPacman();
	_ghost0->drawGhost(RED);
	_ghost1->drawGhost(BLUE);
	_ghost2->drawGhost(GREEN);
	_particle0->drawParticle();
	_particle1->drawParticle();
	_particle2->drawParticle();
	_particle3->drawParticle();
	_particle4->drawParticle();
	_particle5->drawParticle();
	_particle6->drawParticle();
	_particle7->drawParticle();
	_particle8->drawParticle();
	_particle9->drawParticle();
	glEnd();	
	
	glutSwapBuffers();
}


void updateGhosts(int a){
	
	_ghost0->decPrey();
	_ghost1->decPrey();
	_ghost2->decPrey();
	
}

void ressurectGhost(int n){
	if(n == 0)
		_ghost0->ressurect();
	else if(n == 1)
		_ghost1->ressurect();
	if(n == 2)
		_ghost2->ressurect();
}

void ressurectAll(int i){
	_pacman->ressurect();
	_ghost0->ressurect();
	_ghost1->ressurect();
	_ghost2->ressurect();
}

void update() {
	
	float posX = _pacman->getX();
	float posY = _pacman->getY();
	float vx = _pacman->getVX();
	float vy = _pacman->getVY();
	
	elapTime = glutGet(GLUT_ELAPSED_TIME);
	difTime = elapTime - prevTime;
	prevTime = elapTime;
	_pacman->setSpeed(difTime*(SPEED/25.0f));
	_ghost0->setSpeed(difTime*(SPEED/25.0f));
	_ghost1->setSpeed(difTime*(SPEED/25.0f));
	_ghost2->setSpeed(difTime*(SPEED/25.0f));

		/**************************** BALL EATING ****************************/
	if(_maze->isBall(round(posX) + vx, round(posY) + vy) &&
	  (round(posX) + vx - posX) < 1 &&
	  (round(posX) + vx - posX) > -1 &&
	  (round(posY) + vy - posY) < 1 &&
	  (round(posY) + vy - posY) > -1){
		_maze->setMazeInfo(round(posX) + vx, round(posY) + vy, 0);
		_maze->decBalls();
		if(!_pacman->getDead())
			score++;
	}
	
	if(_maze->isSpecialBall(round(posX) + vx, round(posY) + vy) &&
	  (round(posX) + vx - posX) < 1 &&
	  (round(posX) + vx - posX) > -1 &&
	  (round(posY) + vy - posY) < 1 &&
	  (round(posY) + vy - posY) > -1){
		_maze->setMazeInfo(round(posX) + vx, round(posY) + vy, 0);
		_maze->decBalls();
		_ghost0->incPrey();
		_ghost1->incPrey();
		_ghost2->incPrey();
		glutTimerFunc(10000, updateGhosts, 1);
		if(!_pacman->getDead())
			score += 10;
	}
	
		/**************************** TURNS DETECTION ****************************/
	if(!(_maze->isWall(round(_pacman->getX()) + movX, round(_pacman->getY() + movY))) &&
		_pacman->getY() < round(_pacman->getY()) + 0.10 &&
		_pacman->getY() > round(_pacman->getY()) - 0.10 &&
		_pacman->getX() < round(_pacman->getX()) + 0.10 &&
		_pacman->getX() > round(_pacman->getX()) - 0.10) {
 			if(_pacman->getAlive());
				_pacman->updateMovement(movX, movY);
			
			if(keyPressed){
				_pacman->setY(round(_pacman->getY()));
				_pacman->setX(round(_pacman->getX()));
				keyPressed = false;
			}
	}

		/**************************** PACMAN COLLISIONS ****************************/
	if(_maze->isWall(round(posX) + vx, round(posY) + vy) &&
	  (round(posX) + vx - posX) <= 1.5 &&
	  (round(posX) + vx - posX) >= -1.5 &&
	  (round(posY) + vy - posY) <= 1.5 &&
	  (round(posY) + vy - posY) >= -1.5){
		_pacman->setX(round(posX));
		_pacman->setY(round(posY));
		_pacman->setVX(0.0f);
		_pacman->setVY(0.0f);
	}
	else if(_pacman->getVX() == 0 && _pacman->getVY() == 0){}
	else {
		float degVX = (acos((float)_pacman->getVX())*180/PI)*abs(_pacman->getVX());
		float degVY = (asin((float)_pacman->getVY())*180/PI)*abs(_pacman->getVY());
		_pacman->setAngle(degVX + degVY);
		_pacman->movePacman();
	}


		/**************************** MAGIC PORTAL TRANSPORTATION ****************************/
	
	if ((int)posX == 18 && (int) posY == 0 && (int) _pacman->getAngle() == 0){
		_pacman->setX(-18);
	}
	else if ((int) posX == -18 && (int) posY == 0 && (int) _pacman->getAngle() == 180){
		_pacman->setX(18);
	}

		/**************************** GHOST MOVEMENT ****************************/
	
	_ghost0->ghostMovement(_pacman, _ghostmaze);
	_ghost1->ghostMovement(_pacman, _ghostmaze);
	_ghost2->ghostMovement(_pacman, _ghostmaze);
	_ghost0->lookPac(posX, posY);
	_ghost1->lookPac(posX, posY);
	_ghost2->lookPac(posX, posY);

		/**************************** GHOST-PACMAN COLLISIONS ****************************/
	
	bool collision0 = collision(_pacman, _ghost0);
	bool collision1 = collision(_pacman, _ghost1);
	bool collision2 = collision(_pacman, _ghost2);
	
	if(_pacman->getAlive()){
		if(collision0){
			if(_ghost0->getPrey() == 0){
				_pacman->die();
				_particle0->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX);
				_particle1->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle2->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle3->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle4->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle5->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle6->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle7->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle8->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle9->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_ghost0->die();
				_ghost1->die();
				_ghost2->die();
				glutTimerFunc(1500, ressurectAll, 0);
			}
			else{
				_ghost0->die();
				if(!_pacman->getDead())
					score += 100;
				glutTimerFunc(5000, ressurectGhost, 0);
			}
		} 
		else if(collision1){
			if(_ghost1->getPrey() == 0){
				_pacman->die();
				_particle0->explode(_pacman, (float)rand()/(float)RAND_MAX, 5*(float)rand()/(float)RAND_MAX);
				_particle1->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle2->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle3->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle4->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle5->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle6->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle7->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle8->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle9->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_ghost0->die();
				_ghost1->die();
				_ghost2->die();
				glutTimerFunc(1500, ressurectAll, 0);
			}	
			else{
				_ghost1->die();
				if(!_pacman->getDead())
					score += 100;
				glutTimerFunc(5000, ressurectGhost, 1);
			}
		}
		else if(collision2){
			if(_ghost2->getPrey() == 0){
				_pacman->die();
				_particle0->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX);
				_particle1->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle2->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle3->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle4->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle5->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle6->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle7->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle8->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_particle9->explode(_pacman, (float)rand()/(float)RAND_MAX, (float)rand()/(float)RAND_MAX); 
				_ghost0->die();
				_ghost1->die();
				_ghost2->die();
				glutTimerFunc(1500, ressurectAll, 0);
			}
			else{
				_ghost2->die();
				if(!_pacman->getDead())
					score += 100;
				glutTimerFunc(5000, ressurectGhost, 2);
			}
		}
}

	_particle0->moveParticle();
	_particle1->moveParticle();
	_particle2->moveParticle();
	_particle3->moveParticle();
	_particle4->moveParticle();
	_particle5->moveParticle();
	_particle6->moveParticle();
	_particle7->moveParticle();
	_particle8->moveParticle();
	_particle9->moveParticle();

	glutPostRedisplay();

}



int main(int argc, char** argv) {

	srand (time(NULL)); //the seed for random number generation depends on the second the app was launched

	
	//Initialize GLUT
	glutInit(&argc, argv);
	
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
	glutInitWindowSize(800, 800);

	//Create the window
	glutCreateWindow("Pac-man");
	initRendering();
	
	//Set handler functions
	glutDisplayFunc(myDisplay);
	glutKeyboardFunc(handleKeypress);
	glutReshapeFunc(handleResize);
	glutIdleFunc(update);
	
	glutMainLoop();
	return 0;
}









