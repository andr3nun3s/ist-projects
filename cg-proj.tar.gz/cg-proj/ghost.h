#ifndef _GHOST_H_
#define _GHOST_H_

#include <GL/glut.h>
#include <math.h>
#include "pacman.h"
#include "maze.h"



class ghost {

private:
	float _speed, _angle;
	float _x, _y;	//ghost's position
	float _vx, _vy; //ghost's movement vector
	int _prey;		//ghost is a prey while _prey is larger than 0 (works as a semaphore)
	bool _radioactive;
	bool _alive;



public:	
	//Constructor
	ghost(float x, float y)
		: _speed(0.1f), _angle(0.0f), _x(x), _y(y), _vx(1.0f), _vy(0.0f), _prey(false), _radioactive(false), _alive(true) {}
	
	/*Destructor*/
	~ghost();

	void moveGhost();
	void updateMovement(float vx, float vy);
	void setSpeed(float speed);
	void setX(float x);
	void setY(float y);
	void setVX(float vx);
	void setVY(float vy);
	void setAngle(float angle);
	void setPosition(float x, float y);
	void setRadioactive(bool value);
	void ressurect();
	void incPrey();
	void decPrey();
	void die();
	int getPrey();	
	float getX();
	float getY();
	float getVX();
	float getVY();
	float getSpeed();
	float getAngle();
	
	void lookPac (float xp, float yp);
	void drawFace (int angle);
	void drawGhost (float r, float g, float b);
	void drawEye (float x);
	void drawSmallEye();

	float round(float f);

	void ghostMovement(pacman *_pacman, maze *_ghostmaze);


};


#endif
