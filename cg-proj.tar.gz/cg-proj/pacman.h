#ifndef _PACMAN_H_
#define _PACMAN_H_

#include <GL/glut.h>


class pacman {

private:
	float _speed, _angle;
	
	float _x, _y;	//pacman's position
	float _vx, _vy; //pacman's movement vector
	bool _radioactive;
	int _lives;
	bool _alive;
	bool _dead;


public:	
	//Constructor
	pacman(float x, float y)
		: _speed(0.1f), _angle(0.0f), _x(x), _y(y), _vx(0.0f), _vy(0.0f), _radioactive(false), _lives(3), _alive(true), _dead(false) {}

	/*Destructor*/
	~pacman();

	void movePacman();
	void updateMovement(float vx, float vy);
	void setSpeed(float speed);
	void setX(float x);
	void setY(float y);
	void setVX(float vx);
	void setVY(float vy);
	void setAngle(float angle);
	void setPosition(float x, float y);
	void setRadioactive(bool value);
	void setLives(int l);
	void setDead(bool dead);
	void ressurect();
	void die();
	float getX();
	float getY();
	float getVX();
	float getVY();
	float getSpeed();
	float getAngle();
	int getLives();
	bool getAlive();
	bool getDead();

	
	void drawPacman ();
	void drawPacman(float x, float y);
	void drawEye (float x);
	void drawSmallEye();
	void drawEyeBrow (float x);

};


#endif
