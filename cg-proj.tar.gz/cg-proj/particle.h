#ifndef _PARTICLE_H_
#define _PARTICLE_H_

#include <GL/glut.h>

#include "pacman.h"


class particle {

private:
	float _speed, _angle;
	int _id;	
	float _x, _y, _z;	//particle's position
	float _vx, _vy, _vz; //particle's's movement vector
	bool _radioactive;
	bool _alive;


public:	
	//Constructor
	particle(float x, float y, float z, int id)
		: _speed(0.1f), _angle(0.0f), _id(id), _x(x), _y(y), _z(z), _vx(0.0f), _vy(0.0f), _vz(0.0f), _radioactive(false), _alive(false) {}

	/*Destructor*/
	~particle();

	void moveParticle();
	void updateMovement(float vx, float vy, float vz);
	void setSpeed(float speed);
	void setX(float x);
	void setY(float y);
	void setZ(float z);
	void setVX(float vx);
	void setVY(float vy);
	void setVZ(float vz);
	void setAngle(float angle);
	void setPosition(float x, float y, float z);
	void setRadioactive(bool value);
	void explode(pacman *_pacman, float moveVec, float vz);
	void die();
	float getX();
	float getY();
	float getZ();
	float getVX();
	float getVY();
	float getVZ();
	float getSpeed();
	float getAngle();
	bool getAlive();

	
	void drawParticle ();
	void drawParticle(float x, float y);
	void drawEye (float x);
	void drawSmallEye();
	void drawEyeBrow (float x);

};


#endif
