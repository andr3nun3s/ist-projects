cg-proj
=======

Project for my Computer Graphic's course

You need freeGlut to run this.

Just ``make all`` and run ``./main``
