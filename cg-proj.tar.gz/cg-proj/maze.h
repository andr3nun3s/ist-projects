#ifndef _MAZE_H_
#define _MAZE_H_

#include <vector>
#include <GL/glut.h>
#include <iostream>

#define X 41
#define Y 41

using std::vector;

class maze {

private:
	
	int _bluePrint[39][39];

	vector< vector<int> > _bluePrint2;
	int _nballs;

public:	
	
	//constructor
	maze(bool ghost);

	//destructor
	~maze();


//Maze methods
void LoadTexture(const char * bitmap_file);
int getBluePrint(float x, float y);
int getMazeInfo(float x, float y);
void setMazeInfo(float x, float y, int i);
int getBalls();
void setBalls(int num);
void decBalls();
void incBalls();
bool isWall(float x, float y);
bool isBall(float x, float y);
bool isSpecialBall(float x, float y);
void drawMaze (void); //function thats calls all the subfunctions to build up the maze
void drawWall(float wmin, float wmax, float hmin, float hmax); //draws the maze's walls
void drawCenterWall(float wmin, float wmax, float hmin, float hmax);
void drawBall(float tx, float ty, float tz); //draws the small yellow balls in the maze
void drawSpecial(float tx, float ty, float tz); //draws the "special" balls
void drawFloor(float x, float y);
};
#endif

