#include <GL/glut.h>
#include <iostream>
#include <math.h>
#include "particle.h"

#define PI 3.141592653589793


void particle::updateMovement(float vx, float vy, float vz){
	_vx = vx;
	_vy = vy;
	_vz = vz;
}

void particle::moveParticle(){
	if(_z < -0.375)
		_alive = false;
	_vz += -0.07; 
	_x += _speed * _vx;
	_y += _speed * _vy;
	_z += _speed * _vz;
}

void particle::setSpeed(float speed){
	_speed = speed;
}

void particle::setX(float x){
	_x = x;
}

void particle::setY(float y){
	_y = y;
}

void particle::setZ(float z){
	_z = z;
}

void particle::setVX(float vx){
	_vx = vx;
}

void particle::setVY(float vy){
	_vy = vy;
}

void particle::setVZ(float vz){
	_vz = vz;
}

void particle::setAngle(float angle){
	_angle = angle;
}

void particle::setPosition(float x, float y, float z){
	_x = x;
	_y = y;
	_z = z;
}

void particle::setRadioactive(bool value){
	_radioactive = value;
}

void particle::die(){
	_alive = false;
	updateMovement(0.0f, 0.0f, 0.0f);
}

void particle::explode(pacman *_pacman, float moveVec, float vz){
	_alive = true;
	setPosition(_pacman->getX(), _pacman->getY(), 0);
	
	int id = _id;
	
	_vx = moveVec*cos(id*36*PI/(float) 180);
	_vy = moveVec*sin(id*36*PI/(float) 180);
	_vz = vz;
}

float particle::getX(){
	return _x;
}

float particle::getY(){
	return _y;
}

float particle::getZ(){
	return _z;
}

float particle::getVX(){
	return _vx;
}

float particle::getVY(){
	return _vy;
}

float particle::getVZ(){
	return _vz;
}

float particle::getSpeed(){
	return _speed;
}

float particle::getAngle(){
	return _angle;
}

bool particle::getAlive(){
	return _alive;
}

void particle::drawParticle(){
	
	glPushMatrix();
	
	if(_alive){

	GLfloat mat_specular[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_diffuse[] = {0.8, 0.8, 0.0, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(0.8, 0.8, 0.0);

	glTranslatef(_x, _y , _z);
	glScalef(0.1f, 0.1f, 0.1f);
	glRotatef(90, 0.0f, 0.0f, 1.0f);
	glRotatef(_id*36*PI/(float) 180, 0.0f, .0f, 1.0f);
	glutSolidSphere(1.5f, 15.0f, 15.0f);
	drawEye(-.6f);
	drawEye(.6f);		
	drawEyeBrow(-.6f);
	drawEyeBrow(.6f);
	glEnd();
	}

	glPopMatrix();


}

void particle::drawParticle(float x, float y){
	
	glPushMatrix();
	
	GLfloat mat_specular[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_diffuse[] = {0.8, 0.8, 0.0, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(0.8, 0.8, 0.0);

	glTranslatef(x, y , 0.5f);
	glScalef(0.5f, 0.5f, 0.5f);
	glRotatef(-90, 1.0f, 0.0f, 0.0f);
	glRotatef(_id*36*PI/(float) 180, 0.0f, .0f, 1.0f);
	glutSolidSphere(1.5f, 15.0f, 15.0f);
	drawEye(-.6f);
	drawEye(.6f);		
	drawEyeBrow(-.6f);
	drawEyeBrow(.6f);

	glPopMatrix();
	glEnd();

}

void particle::drawEye(float x){
		
	glPushMatrix();

	GLfloat mat_SPECULAR[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_emission0[] = {0.0, 0.0, 0.0, 0.0 };
	GLfloat mat_emission1[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	if(!_radioactive){
		glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission0);}
	else{
		glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission1);}
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(1.0, 1.0, 1.0);

	glColor3f(1.0f, 1.0f, 1.0f);	
	glTranslatef(x, -1.28f, .5f);
	glutSolidSphere(.25f, 10.0f, 10.0f);
	drawSmallEye();

	glPopMatrix();

}

void particle::drawSmallEye(void){

	glPushMatrix();

	GLfloat mat_SPECULAR[] = {1.0, 0.0, 0.0, 1.0 };
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(1.0, 0.0, 0.0);

	glColor3f(1.0f, 0.0f, 0.0f);
	glTranslatef(0.0f, -0.2f, 0.1f);
	glutSolidSphere(.1f, 6.0f, 6.0f);

	glPopMatrix();
}

void particle::drawEyeBrow(float x){

	glPushMatrix();

	GLfloat mat_SPECULAR[] = {0.2, 0.2, 0.2, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0 };
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(0.2, 0.2, 0.2);

	glTranslatef(x, -0.94f, 1.f);	
	glScalef(.7f, 0.25f, .25f);
	glutSolidCube(1.0f);

	glPopMatrix();
}





