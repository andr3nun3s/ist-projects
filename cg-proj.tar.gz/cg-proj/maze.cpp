#include <vector>
#include <stdlib.h>
#include <cstdlib>
#include "maze.h"
#include <GL/glut.h>
extern "C"{
#include "glbmp.h"  //http://chaoslizard.sourceforge.net/glbmp/
}
GLubyte my_texels[64][64][4];
GLuint texName;

int auxbluePrint[39][39] = {	
	{3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3},
	{3,2,3,3,3,1,0,1,0,1,0,1,0,1,0,1,3,3,3,0,3,3,3,1,0,1,0,1,0,1,0,1,0,1,3,3,3,2,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,3,3,1,3,3,3,0,3,3,3,1,3,3,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,0,1,0,1,3,3,3,1,3,3,3,3,3,1,3,3,3,0,3,3,3,1,3,3,3,3,3,1,3,3,3,1,0,1,0,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,3,3,1,3,3,3,0,3,3,3,1,3,3,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,1,0,1,0,1,0,1,0,1,0,1,0,1,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,3,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,0,1,0,1,3,3,3,3,3,3,3,3,3,3,3,1,0,1,0,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,3,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,1,0,0,0,0,0,0,0,0,0,0,0,1,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,1,3,3,3,0,3,3,3,3,3,0,3,3,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,0,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,0,1,0,1,3,3,3,1,3,3,3,1,3,3,3,0,3,3,0,3,3,0,3,3,3,3,3,1,3,3,3,1,0,1,0,1,3},
	{3,3,3,3,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,0,3,3,0,3,3,3,3,3,0,3,3,3,3,3,3,3,3,3},
	{3,3,3,3,3,3,3,3,3,1,3,3,3,1,3,3,3,0,3,3,0,3,3,0,3,3,3,3,3,1,3,3,3,3,3,3,3,3,3},
	{3,3,3,3,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,0,3,3,0,3,3,3,3,3,0,3,3,3,3,3,3,3,3,3},
	{3,1,0,1,0,1,3,3,3,1,3,3,3,1,3,3,3,0,3,3,0,3,3,0,3,3,3,3,3,1,3,3,3,1,0,1,0,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,0,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,1,3,3,3,0,3,3,3,3,3,0,3,3,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,1,0,0,0,0,0,0,0,0,0,0,0,1,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,3,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,0,1,0,1,3,3,3,3,3,3,3,3,3,3,3,1,0,1,0,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,3,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,1,0,1,0,1,0,1,0,1,0,1,0,1,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,3,3,1,3,3,3,0,3,3,3,1,3,3,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,0,1,0,1,3,3,3,1,3,3,3,3,3,1,3,3,3,0,3,3,3,1,3,3,3,3,3,1,3,3,3,1,0,1,0,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,1,3,3,3,1,3,3,3,1,3,3,3,3,3,1,3,3,3,0,3,3,3,1,3,3,3,3,3,1,3,3,3,1,3,3,3,1,3},
	{3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3,3,3,3,3,0,3,3,3,0,3,3,3,0,3},
	{3,2,3,3,3,1,0,1,0,1,0,1,0,1,0,1,3,3,3,0,3,3,3,1,0,1,0,1,0,1,0,1,0,1,3,3,3,2,3},
	{3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3}
};

maze::maze(bool ghost){

		_nballs = 177;
		for (int i = 0; i < 39; i++){
			for (int j = 0; j < 39; j++){
        		_bluePrint[i][j] = auxbluePrint[i][j];
		        }
		}
		

	if(ghost){

	_bluePrint[19][22] = 0;
	_bluePrint[19][21] = 0; //the door is passable for ghosts
		

	for(int i = 0; i < 38; i++){		
			for (int j = 0; j < 38; j++){
				if((int) (_bluePrint[i][j]) == 3){
					continue;}
				if((((int) (_bluePrint[i][j+1]) == 0 ) && ((int) (_bluePrint[i+1][j]) == 0)) ||
					 (((int) (_bluePrint[i][j+1]) == 0) && ((int) (_bluePrint[i-1][j]) == 0))){
					_bluePrint[i][j] = 4;
				}
			}
	}

		for(int i = 0; i < 38; i++){		
				for (int j = 0; j < 38; j++){
					if((int) (_bluePrint[i][j]) == 3){
						continue;}
					if((((int) (_bluePrint[i][j-1]) == 0) && ((int) (_bluePrint[i+1][j]) == 0)) ||
						(((int) (_bluePrint[i][j-1]) == 0) && ((int) (_bluePrint[i-1][j]) == 0))){
						_bluePrint[i][j] = 5;
					}
				}
		}


		for(int i = 0; i < 38; i++){		
				for (int j = 0; j < 38; j++){
					if((int) (_bluePrint[i][j]) == 3){
					continue;}
					if(((int) (_bluePrint[i-1][j]) == 0) && ((int) (_bluePrint[i][j+1]) == 0) && ((int) (_bluePrint[i][j-1]) == 0) ){
					_bluePrint[i][j] = 6;
					}
				}
		}

		for(int i = 0; i < 38; i++){		
			for (int j = 0; j < 38; j++){
				if((int) (_bluePrint[i][j]) == 3){
					continue;}
				if(((int) (_bluePrint[i+1][j]) == 0) && ((int) (_bluePrint[i][j+1]) == 0) && ((int) (_bluePrint[i][j-1]) == 0) ){
					_bluePrint[i][j] = 7;
					}
				}
		} 
		_bluePrint[16][20] = 4;
		_bluePrint[22][20] = 4;
		_bluePrint[1][1] = 4;
		_bluePrint[1][37] = 4;
		_bluePrint[37][1] = 5;
		_bluePrint[37][37] = 5;
		_bluePrint[9][19] = 0;
		_bluePrint[29][19] = 0;
		_bluePrint[19][23] = 4;
	}
}

int maze::getBluePrint(float x, float y){
	return _bluePrint[(int) x][(int) y];
}

int maze::getMazeInfo(float x, float y){		//returns the content of a given position
	return _bluePrint[(int) x + 19][(int) y + 19];
}

void maze::setMazeInfo(float x, float y, int i){		//sets the content of a given position to given integer
	_bluePrint[(int) x + 19][(int) y + 19] = i;
}



int maze::getBalls(){
	return _nballs;
}

void maze::setBalls(int num){
	_nballs = num;
}

void maze::decBalls(){
	_nballs--;
}

void maze::incBalls(){
	_nballs++;
}

bool maze::isWall(float x, float y){	//verifies if a given position is a wall
	if(_bluePrint[(int)x+19][(int)y+19] == 3)
		return true;
	else
		return false;
}

bool maze::isBall(float x, float y){	//verifies if a given position has a ball
	if(_bluePrint[(int)x+19][(int)y+19] == 1)
		return true;
	else
		return false;
}

bool maze::isSpecialBall(float x, float y){	//verifies if a given position has a special ball
	if(_bluePrint[(int)x+19][(int)y+19] == 2)
		return true;
	else
		return false;
}


void maze::drawMaze(void) {	//calls all the methods to build up the maze

	//EXTERIOR WALLS
	drawWall(-20, -19, -20, -1);
	drawWall(-20, 20, -20, -19);
	drawWall(19, 20, -20, -1);
	drawWall(-20, 20, 19, 20);
	drawWall(-20, -19, 1, 20);
	drawWall(19, 20, 1, 20);
	
	//BOTTOM
	drawWall(-19, -15, -17, -15); 	//A
	drawWall(-13, -3, -17, -15);	//B
	drawWall(-1, 1, -19, -13);		//C
	drawWall(3, 13, -17, -15);		//D
	drawWall(15, 19, -17, -15);	//E
	drawWall(-17, 17, -13, -11);	//F
	drawWall(-17, -9, -9, -7);		//G
	drawWall(-7, 7, -9, -7);		//H
	drawWall(9, 17, -9, -7);		//I
	drawWall(-17, -11, -7, -5);	//J
	drawWall(11, 17, -7, -5);		//K
	drawWall(-19, -11, -3, -1);	//L
	drawWall(-5, 5, -5, -3);		//M
	drawWall(11, 19, -3, -1);		//N
	drawWall(-9, -7, -5, 5);		//O
	drawWall(7, 9, -5, 5);			//P
	
	
	//TOP
	drawWall(-19, -15, 15, 17); 	//A
	drawWall(-13, -3, 15, 17);		//B
	drawWall(-1, 1, 13, 19);		//C
	drawWall(3, 13, 15, 17);		//D
	drawWall(15, 19, 15, 17);		//E
	drawWall(-17, 17, 11, 13);		//F
	drawWall(-17, -9, 7, 9);		//G
	drawWall(-7, 7, 7, 9);			//H
	drawWall(9, 17, 7, 9);			//I
	drawWall(-17, -11, 5, 7);		//J
	drawWall(11, 17, 5, 7);		//K
	drawWall(-19, -11, 1, 3);		//L
	drawWall(-5, 5, 5, 7);			//M
	drawWall(11, 19, 1, 3);		//N

	//CENTER

	GLfloat mat_SPECULAR0[] = {0.1, 0.1, 0.8, 1.0 };
	GLfloat mat_emission0[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission0);
	GLfloat mat_shine0 = 0.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR0);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR0);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine0);

	drawCenterWall(-5, 5, -1, -.25);	//1
	drawCenterWall(-5, -4.25, -1, 3);	//2
	drawCenterWall(-5, -2, 2.25, 3);	//3
	drawCenterWall(4.25, 5, -1, 3);		//4
	drawCenterWall(2, 5, 2.25, 3);		//5
	
	GLfloat mat_SPECULAR1[] = {0.4, 0.4, 0.4, 1.0 };
	GLfloat mat_emission1[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission1);
	GLfloat mat_shine1 = 0.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR1);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR1);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine1);

	glColor3f(0.7f, 0.8f, 0.8f);						//color: greyish

	drawCenterWall(-2, 2, 2.25, 3);		//gate

	//Balls
	for(int i = 0; i <= 38; i++){
		for(int j = 0; j <= 38; j++){
			if(_bluePrint[i][j] == 1)
				drawBall((float) i - 19, (float) j - 19, 0.0f);
			else if(_bluePrint[i][j] == 2)
				drawSpecial((float) i - 19, (float) j - 19, 0.0f);
		}
	}

	//Floor
	for (int i = 0; i < 64; i ++) {
		for (int j = 0; j < 64; j ++) {
			my_texels[i][j][0] = (GLubyte) 0;
			my_texels[i][j][1] = (GLubyte) 0;
			my_texels[i][j][2] = (GLubyte) 0;
			my_texels[i][j][3] = (GLubyte) 255;
		}
	}
	for (int i = 0; i < 64; i += 2) {
		for (int j = 0; j < 64; j += 2) {
			my_texels[i][j][0] = (GLubyte) 255;
			my_texels[i][j][1] = (GLubyte) 255;
			my_texels[i][j][2] = (GLubyte) 255;
			my_texels[i][j][3] = (GLubyte) 255;
		}
	}

	for (int i = 1; i < 64; i += 2) {
		for (int j = 1; j < 64; j += 2) {
			my_texels[i][j][0] = (GLubyte) 255;
			my_texels[i][j][1] = (GLubyte) 255;
			my_texels[i][j][2] = (GLubyte) 255;
			my_texels[i][j][3] = (GLubyte) 255;
		}
	}

	glGenTextures(1, &texName);
	glBindTexture(GL_TEXTURE_2D, texName);

	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, 64, 
				64, 0, GL_RGBA, GL_UNSIGNED_BYTE, 
				my_texels);
	glEnable(GL_TEXTURE_2D);
    glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_MODULATE);
    glBindTexture(GL_TEXTURE_2D, texName);
    
	//LoadTexture("metal-cyanide2.bmp");    

	for(int j = -19; j <= 19; j++){
		for(int i = -20; i <= 19; i++){
			drawFloor(i, j);
		}
	}
	glDisable(GL_TEXTURE_2D);


}

void maze::drawWall(float wmin, float wmax, float hmin, float hmax){

	glPushMatrix();

	GLfloat mat_SPECULAR[] = {0.1, 0.1, 0.8, 1.0 };
	GLfloat mat_diffuse[] = {0.1, 0.1, 0.8, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 0.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);
	
	for(float xmin = wmin; xmin < wmax; xmin++){	//faces lateral inferior
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin, hmin, -0.375f);
		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin+1, hmin, -0.375f);
		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin+1, hmin, 0.375f);
		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin, hmin, 0.375f);
		glEnd();
	}

	for(float xmin = wmin; xmin < wmax; xmin++){	//faces lateral superior
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin, hmax, -0.375f);
		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin+1, hmax, -0.375f);
		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin+1, hmax, 0.375f);
		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin, hmax, 0.375f);
		glEnd();
	}

	for(float ymin = hmin; ymin < hmax; ymin++){	//face esquerda
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin, -0.375f);
		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin+1, -0.375f);
		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin+1, 0.375f);
		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin, 0.375f);
		glEnd();
	}

	for(float ymin = hmin; ymin < hmax; ymin++){	//faces direita
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin, -0.375f);
		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin+1, -0.375f);
		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin+1, 0.375f);
		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin, 0.375f);
		glEnd();
	}

	for(float ymin = hmin; ymin < hmax; ymin++){	//face topo
		for(float xmin = wmin; xmin < wmax; xmin++){
			glBegin(GL_TRIANGLE_FAN);

			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin, ymin, 0.375f);
			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin+1, ymin, 0.375f);
			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin+1, ymin+1, 0.375f);
			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin, ymin+1, 0.375f);
			glEnd();
		}
	}		

	glPopMatrix();

}

void maze::drawCenterWall(float wmin, float wmax, float hmin, float hmax){	//draws the maze's walls
	
	glPushMatrix();
	
	for(float xmin = wmin; xmin < wmax; xmin+= 0.25){	//faces lateral inferior
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin, hmin, -0.375f);
		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin+0.25, hmin, -0.375f);
		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin+0.25, hmin, 0.375f);
		glNormal3f(0.0, -1.0, 0.0);
		glVertex3f(xmin, hmin, 0.375f);
		glEnd();
	}

	for(float xmin = wmin; xmin < wmax; xmin+= 0.25){	//faces lateral superior
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin, hmax, -0.375f);
		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin+0.25, hmax, -0.375f);
		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin+0.25, hmax, 0.375f);
		glNormal3f(0.0, 1.0, 0.0);
		glVertex3f(xmin, hmax, 0.375f);
		glEnd();
	}

	for(float ymin = hmin; ymin < hmax; ymin+= 0.25){	//face esquerda
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin, -0.375f);
		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin+0.25, -0.375f);
		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin+0.25, 0.375f);
		glNormal3f(-1.0, 0.0, 0.0);
		glVertex3f(wmin, ymin, 0.375f);
		glEnd();
	}

	for(float ymin = hmin; ymin < hmax; ymin+= 0.25){	//faces direita
		glBegin(GL_TRIANGLE_FAN);

		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin, -0.375f);
		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin+0.25, -0.375f);
		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin+0.25, 0.375f);
		glNormal3f(1.0, 0.0, 0.0);
		glVertex3f(wmax, ymin, 0.375f);
		glEnd();
	}

	for(float ymin = hmin; ymin < hmax; ymin+= 0.25){	//face topo
		for(float xmin = wmin; xmin < wmax; xmin+= 0.25){
			glBegin(GL_TRIANGLE_FAN);

			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin, ymin, 0.375f);
			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin+0.25, ymin, 0.375f);
			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin+0.25, ymin+0.25, 0.375f);
			glNormal3f(0.0, 0.0, 1.0);
			glVertex3f(xmin, ymin+0.25, 0.375f);
			glEnd();
		}
	}		

	glPopMatrix();
}

void maze::drawBall(float tx, float ty, float tz){	//draws the small yellow balls in the maze
	
	glPushMatrix();

	GLfloat mat_SPECULAR[] = {1.0, 1.0, 0.0, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};

	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);
	
	//glColor3f(0.0f, 0.0f, 0.5f);

	glTranslatef(tx, ty, tz);
	glutSolidSphere(0.3f, 10, 10);

	glPopMatrix();
}

void maze::drawSpecial(float tx, float ty, float tz){

	glPushMatrix();

	//glColor3f(0.0f, 0.0f, 0.5f);

	GLfloat mat_SPECULAR[] = {0.85, 0.6, 0.0, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glTranslatef(tx, ty, tz);
	glutSolidSphere(0.5f, 15, 15);

	glPopMatrix();
}

void maze::drawFloor(float x, float y){

	float i = x;
	float j = y;

	GLfloat mat_diffuse[] = {1, 1, 1, 1.0};
	GLfloat mat_specular[] = {0.0, 0.0, 0.0, 1.0};
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	GLfloat mat_shine = 0.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glBegin(GL_QUADS);

	glNormal3f(0.0, 0.0, 1.0);
	glTexCoord2f(i/(float)80, j/(float)78);
	glVertex3f(i, j, -0.375f);
	glNormal3f(0.0, 0.0, 1.0);
	glTexCoord2f((i+1)/(float)80, j/(float)78);
	glVertex3f(i+1, j, -0.375f);
	glNormal3f(0.0, 0.0, 1.0);
	glTexCoord2f((i+1)/(float)80, (j+1)/(float)78);
	glVertex3f(i+1, j+1, -0.375f);
	glNormal3f(0.0, 0.0, 1.0);
	glTexCoord2f(i/(float)80, (j+1)/(float)78);
	glVertex3f(i, j+1, -0.375f);
	
	glEnd();

}
