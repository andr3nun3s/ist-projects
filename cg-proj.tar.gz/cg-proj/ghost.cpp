#include <iostream>
#include <math.h>
#include <stdlib.h>
#include <time.h>
#include <cstdlib>
#include "ghost.h"


void ghost::updateMovement(float vx, float vy){
	_vx = vx;
	_vy = vy;
}

void ghost::moveGhost(){
	if(_prey > 0){
	_x += (_speed*0.75) * _vx;
	_y += (_speed*0.75) * _vy;
	}
	else{
	_x += (_speed) * _vx;
	_y += (_speed) * _vy;
	}
}

void ghost::setSpeed(float speed){
	_speed = speed;
}

void ghost::setX(float x){
	_x = x;
}

void ghost::setY(float y){
	_y = y;
}

void ghost::setVX(float vx){
	_vx = vx;
}

void ghost::setVY(float vy){
	_vy = vy;
}

void ghost::setAngle(float angle){
	_angle = angle;
}

void ghost::setPosition(float x, float y){
	_x = x;
	_y = y;
}

void ghost::setRadioactive(bool value){
	_radioactive = value;
}

void ghost::ressurect(){
		_x = 2.5f;
		_y = 1.0f;
		_alive = true;
}

void ghost::die(){
	_alive = false;
		_x = 0.0f;
		_y = 1.0f;
	

}

float ghost::getX(){
	return _x;
}

float ghost::getY(){
	return _y;
}

float ghost::getVX(){
	return _vx;
}

float ghost::getVY(){
	return _vy;
}

float ghost::getSpeed(){
	return _speed;
}

float ghost::getAngle(){
	return _angle;
}

int ghost::getPrey(){
	return _prey;
}

void ghost::lookPac (float xp, float yp){
	
	float y = yp - _y;
	float x = xp - _x;
	_angle = (atan2 (y,x) * 180) / 3.141592653589793;
}

void ghost::incPrey(){
	_prey += 1;
}

void ghost::decPrey(){
	_prey -= 1;
}

void ghost::drawGhost(float r, float g, float b){
glPushMatrix();
	if(_alive){
		if(!_prey){
			GLfloat mat_SPECULAR[] = {r, g, b, 1.0 };
			GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
			glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
			GLfloat mat_shine = 100.0;
	
			glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
			glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);	
			glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);
		}
		else{
			GLfloat mat_SPECULAR[] = {1.0, 1.0, 1.0, 1.0 };
			GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
			glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
			GLfloat mat_shine = 100.0;
	
			glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
			glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
			glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);
		}
		
		glTranslatef(_x, _y , 0.5f);
		glRotatef(_angle, 0.0f, 0.0f, 1.0f);
		glRotatef(90, 0.0f, 0.0f, 1.0f);
		glColor3f(r,g,b);
		drawFace(0);
		drawFace(45);
		drawFace(90);	
		drawFace(135);
		drawFace(180);
		drawFace(225);
		drawFace(270);
		drawFace(315);
		drawEye(-0.4f);
		drawEye(0.4f);
	}
glPopMatrix();
}

void ghost::drawFace(int angle){
	
	glPushMatrix();
	
	glScalef(0.17f, 0.17f, 0.17f);
	glRotatef(angle, 0.0f, 0.0f, 1.0f);
	glTranslatef(0, 4.83, 0.0); //tg 22.5 = x / 2y
	

	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.0, 1.0, 0.0);
	glVertex3f(0.0f, 0.0f, -9.0f);
	glNormal3f(-0.707106781f, 1.707106781f, 0); 	
	glVertex3f(-2.0f, 0.0f, -8.0f);		
	glNormal3f(-1.257918415f, 2.486072069f, 1.254134105f);
	glVertex3f(-2.0f, 0.0f, 2.0f);
	glNormal3f(1.257918415f, 2.486072069f, 1.254134105);		
	glVertex3f(2.0f, 0.0f, 2.0f);
	glNormal3f(0.707106781f, 1.707106781f, 0);
	glVertex3f(2.0f, 0.0f, -8.0f);

	glEnd();
	
	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.0, 0.0, 1.0);
	glVertex3f(0.0f, -4.83f, 4.0f);
	glNormal3f(0.707106781f, 1.707106781f, 6.830f);	
	glVertex3f(1.0f, -2.415f, 4.0f);
	glNormal3f(-0.707106781f, 1.707106781f, 6.830f);	
	glVertex3f(-1.0f, -2.415f, 4.0f);
	
	glEnd();	
	
	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(0.707106781f, 1.707106781f, 6.830f);		
	glVertex3f(1.0f, -2.415f, 4.0f);
	glNormal3f(-0.707106781f, 1.707106781f, 6.830f);	
	glVertex3f(-1.0f, -2.415f, 4.0f);
	glNormal3f(-1.257918415, 3.106271658, 6.084134105);
	glVertex3f(-1.5f, -1.2075f, 3.5f);
	glNormal3f(1.257918415, 3.106271658, 6.084134105);
	glVertex3f(1.5f, -1.2075f, 3.5f);
	
	glEnd();	
	
	glBegin(GL_TRIANGLE_FAN);
	glNormal3f(-1.257918415, 3.106271658, 6.084134105);
	glVertex3f(-1.5f, -1.2075f, 3.5f);
	glNormal3f(1.257918415, 3.106271658, 6.084134105);
	glVertex3f(1.5f, -1.2075f, 3.5f);
	glNormal3f(1.257918415f, 2.486072069f, 1.254134105);		
	glVertex3f(2.0f, 0.0f, 2.0f);
	glNormal3f(-1.257918415f, 2.486072069f, 1.254134105f);
	glVertex3f(-2.0f, 0.0f, 2.0f);

	
	glEnd();

	glPopMatrix();
	
}

void ghost::drawEye(float x){
		
	glPushMatrix();

	GLfloat mat_SPECULAR[] = {1.0, 1.0, 1.0, 1.0};
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(1.0f, 1.0f, 1.0f);	
	glTranslatef(x, -0.8f, .5f);
	glutSolidSphere(.25f, 10.0f, 10.0f);
	drawSmallEye();
	glPopMatrix();

}

void ghost::drawSmallEye(void){
	glPushMatrix();

	GLfloat mat_SPECULAR[] = {1.0, 1.0, 0.0, 1.0 };
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(1.0f, 1.0f, 0.0f);
	glTranslatef(0.0f, -0.2f, 0.1f);
	glutSolidSphere(.1f, 6.0f, 6.0f);
	glPopMatrix();
}

float ghost::round(float f)
{
	if(f < 0){
		return ((floor(f*-1 + 0.5))*-1);}
	else
		return floor(f + 0.5);
}

void ghost::ghostMovement(pacman *_pacman, maze *_ghostmaze){

	float ghostMovX = 0;
	float ghostMovY = 0;
	float curvePosX = 10;
	float curvePosY = 10;
	//bool //curve = false;

	float y = _pacman->getY() - getY();
	float x = _pacman->getX() - getX();
	float _pacangle = (atan2 (y,x) * 180) / 3.141592653589793;
	int _quadrant; // four quandrants to find where the pacman is

	if	((_pacangle > 0.0f) && (_pacangle <= 90.0f))
		_quadrant = 1; 	
	else if	((_pacangle > 90.0f) && (_pacangle <= 180.0f))
		_quadrant = 2;
	else if	((_pacangle > -180.0f) && (_pacangle <= -90.0f))
		_quadrant = 3;
	else if	((_pacangle > -90.0f) && (_pacangle <= 0.0f))
		_quadrant = 4;
	else
		_quadrant = 1;


	float posX = getX();
	float posY = getY();
	float vx = getVX();
	float vy = getVY();
	
	float rndm = (float)rand()/(float)RAND_MAX;	//generates a 'random' number between 0.0 and 1.0

	/* colisions */
	if(_ghostmaze->isWall(round(posX) + vx, round(posY) + vy) &&
	(round(posX) + vx - posX) <= 1.5 &&
	(round(posX) + vx - posX) >= -1.5 &&
	(round(posY) + vy - posY) <= 1.5 &&
	(round(posY) + vy - posY) >= -1.5){
		setX(round(posX));
		setY(round(posY));
	updateMovement(0.0f, 0.0f);
	//std::cout << "COLIDIU ";
	}
	else if ((curvePosX - round(posX) == 0) && (curvePosY - round(posY)) == 0 &&
		(getVX() != 0 || getVY() != 0))
			moveGhost();

	else {	//std::cout << "actualizar ";
		if (getPrey() == 0){
			//segue
			// PREY E INVALIDO 
		if(_quadrant == 1){ //pacman is up and/or to the right
		
			switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 

						////std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){ // %50 chance to pick each option
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
								////curve = true;
							}		
							else{
								//updateMovement(1.0f, 0.0f);}
								ghostMovX = 1;
								ghostMovY = 0;
							//curve = true;
							}
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
					//	moveGhost();						
															
						break;

				case 5: //left/right and down

						////std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);


						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(1.0f, 0.0f);
							ghostMovX = 1;
							ghostMovY = 0;
							//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, -1.0f);						
							ghostMovX = 0;
						ghostMovY = -1;
						//curve = true;
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
					//	moveGhost();	
						break; 
						
				case 6: // up/down and left

						////std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);


						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, 1.0f);}
							ghostMovX = 0;
							ghostMovY = 1;
						//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, -1.0f);
							ghostMovX = 0;
							ghostMovY = -1;
						//curve = true;
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
					//	moveGhost();			
						break;

				case 7: // up/down and right

						////std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);


						 if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
							//curve = true;
							}
							else{
								//updateMovement(1.0f, 0.0f);
								ghostMovX = 1;
								ghostMovY = 0;
							//curve = true;
							}
						}
						else{
							//updateMovement(0.0f, -1.0f);
							ghostMovX = 0;
							ghostMovY = -1;
						//curve = true;
						}
					//	moveGhost();																				
					break;
				default:
					//	moveGhost(); 
   						break;
			}
			
		}
		if(_quadrant == 2){ //pacman is up and/or to the right
			switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 

							//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
							else{
								//updateMovement(-1.0f, 0.0f);						
								ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
					//	moveGhost();
						break;

				case 5: //left/right and down
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(-1.0f, 0.0f);}
							ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f)
							//updateMovement(0.0f, -1.0f);
							{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						//moveGhost();
						break;
						
				case 6: // up/down and left
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
							else
								//updateMovement(-1.0f, 0.0f);						
								{ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else
							//updateMovement(0.0f, -1.0f);
							{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						//moveGhost();
						break;

				case 7: // up/down and right
							//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, 1.0f);}
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f)
							//updateMovement(0.0f, -1.0f);						
							{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
							ghostMovY =0;
							//curve = true;
						}
						//moveGhost();																				
						break;

				default:
						//moveGhost(); 
						break;
			}	
		}
		if(_quadrant == 3){ //pacman is down and/or to the left
			switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 
							//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(-1.0f, 0.0f);}
							ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						moveGhost(); 
						break;

				case 5: //left/right and down
					//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f)
								//updateMovement(0.0f, -1.0f);
								{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
							else
								//updateMovement(-1.0f, 0.0f);						
								{ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						//moveGhost();
						break;
						
				case 6: // up/down and left
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f)
								//updateMovement(0.0f, -1.0f);
								{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
							else
								//updateMovement(-1.0f, 0.0f);
								{ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else{
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						//moveGhost();																				
						break;

				case 7: // up/down and right
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						 if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, -1.0f);}
							 ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
//							updateMovement(0.0f, 1.0f);						
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						//moveGhost();																				
						break;
				default:
						//moveGhost(); 
   						break;
			} 
			
		}
		if(_quadrant == 4){ //pacman is down and/or to the right
			
			switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(1.0f, 0.0f);}
							ghostMovX = 1;
							ghostMovY = 0;
						//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, 1.0f);						
							ghostMovX = 0;
							ghostMovY = 1;
						//curve = true;
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
						//moveGhost();	
																									
						break;

				case 5: //left/right and down
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, -1.0f);
								ghostMovX = 0;
								ghostMovY = -1;
							//curve = true;
							}
							else{
								//updateMovement(1.0f, 0.0f);
								ghostMovX = 1;
								ghostMovY = 0;
							//curve = true;
							}
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
						//moveGhost();
						break;
						
				case 6: // up/down and left
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, -1.0f);}
							ghostMovX = 0;
							ghostMovY = -1;
						//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
							ghostMovY = 1;
						//curve = true;
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = 1;
							ghostMovY = 0;
							//curve = true;
						}
						//moveGhost();
																										
						break;

				case 7: // up/down and right
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						 if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, -1.0f);
								ghostMovX = 0;
							ghostMovY = -1;
							//curve = true;
						}
							else{
								//updateMovement(1.0f, 0.0f);						
								ghostMovX = 1;
							ghostMovY = 0;
							//curve = true;
							}
						}
							else{
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
							ghostMovY = 1;
							//curve = true;
						}
						//moveGhost();																				
						break;
				default:
						//moveGhost(); 
   						break;
			}
		}
		moveGhost();
	}
	/* PREY E VALIDO */
	else{
		if(_quadrant == 1){ //pacman is up and/or to the right
		switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 
							//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(-1.0f, 0.0f);}
							ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						moveGhost(); 
						break;

				case 5: //left/right and down
					//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f)
								//updateMovement(0.0f, -1.0f);
								{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
							else
								//updateMovement(-1.0f, 0.0f);						
								{ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						//moveGhost();
						break;
						
				case 6: // up/down and left
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f)
								//updateMovement(0.0f, -1.0f);
								{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
							else
								//updateMovement(-1.0f, 0.0f);
								{ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else{
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						//moveGhost();																				
						break;

				case 7: // up/down and right
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						 if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, -1.0f);}
							 ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
//							updateMovement(0.0f, 1.0f);						
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						//moveGhost();																				
						break;
				default:
						//moveGhost(); 
   						break;
			} 
			
		}
		if(_quadrant == 2){ //pacman is down and/or to the right
			
			switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(1.0f, 0.0f);}
							ghostMovX = 1;
							ghostMovY = 0;
						//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, 1.0f);						
							ghostMovX = 0;
							ghostMovY = 1;
						//curve = true;
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
						//moveGhost();	
																									
						break;

				case 5: //left/right and down
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, -1.0f);
								ghostMovX = 0;
								ghostMovY = -1;
							//curve = true;
							}
							else{
								//updateMovement(1.0f, 0.0f);
								ghostMovX = 1;
								ghostMovY = 0;
							//curve = true;
							}
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
						//moveGhost();
						break;
						
				case 6: // up/down and left
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, -1.0f);}
							ghostMovX = 0;
							ghostMovY = -1;
						//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
							ghostMovY = 1;
						//curve = true;
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = 1;
							ghostMovY = 0;
							//curve = true;
						}
						//moveGhost();
																										
						break;

				case 7: // up/down and right
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						 if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, -1.0f);
								ghostMovX = 0;
							ghostMovY = -1;
							//curve = true;
						}
							else{
								//updateMovement(1.0f, 0.0f);						
								ghostMovX = 1;
							ghostMovY = 0;
							//curve = true;
						}
						}
							else{
							//updateMovement(0.0f, 1.0f);
							ghostMovX = 0;
							ghostMovY = 1;
							//curve = true;
						}
						//moveGhost();																				
						break;
				default:
						//moveGhost(); 
   						break;
			}
		}
		if(_quadrant == 3){ //pacman is up and/or to the right
		
			switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 

						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){ // %50 chance to pick each option
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}		
							else{
								//updateMovement(1.0f, 0.0f);}
								ghostMovX = 1;
								ghostMovY = 0;
							//curve = true;
							}
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
					//	moveGhost();						
															
						break;

				case 5: //left/right and down

						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);


						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(1.0f, 0.0f);
							ghostMovX = 1;
							ghostMovY = 0;
							//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, -1.0f);						
							ghostMovX = 0;
						ghostMovY = -1;
						//curve = true;
					}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
					//	moveGhost();	
						break; 
						
				case 6: // up/down and left

						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);


						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, 1.0f);}
							ghostMovX = 0;
							ghostMovY = 1;
						//curve = true;
						}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f){
							//updateMovement(0.0f, -1.0f);
							ghostMovX = 0;
							ghostMovY = -1;
						//curve = true;
						}
						else{
							//updateMovement(-1.0f, 0.0f);
							ghostMovX = -1;
							ghostMovY = 0;
						//curve = true;
						}
					//	moveGhost();			
						break;

				case 7: // up/down and right

						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);


						 if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
							//curve = true;
							}
							else{
								//updateMovement(1.0f, 0.0f);
								ghostMovX = 1;
								ghostMovY = 0;
							//curve = true;
							}
						}
						else{
							//updateMovement(0.0f, -1.0f);
							ghostMovX = 0;
							ghostMovY = -1;
						//curve = true;
						}
					//	moveGhost();																				
					break;
				default:
					//	moveGhost(); 
   						break;
			}
			
		}
		if(_quadrant == 4){ //pacman is up and/or to the right
			switch (_ghostmaze->getMazeInfo(round(posX), round(posY))){	
				case 4: // left/right and up 

							//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
							else{
								//updateMovement(-1.0f, 0.0f);						
								ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
					//	moveGhost();
						break;

				case 5: //left/right and down
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);
						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(-1.0f, 0.0f);}
							ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f)
							//updateMovement(0.0f, -1.0f);
							{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
								ghostMovY =0;
								//curve = true;
							}
						//moveGhost();
						break;
						
				case 6: // up/down and left
						//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							if(((float)rand()/(float)RAND_MAX) < 0.5f){
								//updateMovement(0.0f, 1.0f);
								ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
							else
								//updateMovement(-1.0f, 0.0f);						
								{ghostMovX = -1;
								ghostMovY =0;
								//curve = true;
							}
						}
						else
							//updateMovement(0.0f, -1.0f);
							{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						//moveGhost();
						break;

				case 7: // up/down and right
							//std::cout << _ghostmaze->getMazeInfo(round(posX), round(posY)) << std::endl;
						curvePosX = round(posX);
						curvePosY = round(posY);

						if(rndm <= 0.75f){		// has 75% chance of following the pacman
							//updateMovement(0.0f, 1.0f);}
							ghostMovX = 0;
								ghostMovY = 1;
								//curve = true;
							}
						else if(((float)rand()/(float)RAND_MAX) < 0.5f)
							//updateMovement(0.0f, -1.0f);						
							{ghostMovX = 0;
								ghostMovY = -1;
								//curve = true;
							}
						else
							//updateMovement(1.0f, 0.0f);
							{ghostMovX = 1;
							ghostMovY = 0;
							//curve = true;
						}
						//moveGhost();																				
						break;

				default:
						//moveGhost(); 
						break;
			}	
		}
		moveGhost();
	}
}	

	if(!(_ghostmaze->isWall(round(getX()) + ghostMovX, round(getY() + ghostMovY))) &&
		round(getY()) - getY() <  0.10 &&
		round(getY()) - getY() >  - 0.10 &&
		round(getX()) - getX() <  0.10 &&
		round(getX()) - getX() >  - 0.10 &&
		(ghostMovX != 0 || ghostMovY != 0 ) ){
 			
			updateMovement(ghostMovX, ghostMovY);

				setY(round(getY()));
				setX(round(getX()));
			
			
	}
}
