#include <GL/glut.h>
#include <iostream>
#include "pacman.h"


void pacman::updateMovement(float vx, float vy){
	_vx = vx;
	_vy = vy;
}

void pacman::movePacman(){
	_x += _speed * _vx;
	_y += _speed * _vy;
}

void pacman::setSpeed(float speed){
	_speed = speed;
}

void pacman::setX(float x){
	_x = x;
}

void pacman::setY(float y){
	_y = y;
}

void pacman::setVX(float vx){
	_vx = vx;
}

void pacman::setVY(float vy){
	_vy = vy;
}

void pacman::setAngle(float angle){
	_angle = angle;
}

void pacman::setPosition(float x, float y){
	_x = x;
	_y = y;
}

void pacman::setDead(bool dead){
	_dead = dead;
}

void pacman::setRadioactive(bool value){
	_radioactive = value;
}

void pacman::setLives(int l){
	_lives = l;
}

void pacman::die(){
	_alive = false;
	_lives--;
	updateMovement(0.0f, 0.0f);
	if(_lives < 1)
		_dead = true;
}

void pacman::ressurect(){
	_x = 0.0f;
	_y = -2.0f;
	updateMovement(0.0f, 0.0f);
	_alive = true;
}

float pacman::getX(){
	return _x;
}

float pacman::getY(){
	return _y;
}

float pacman::getVX(){
	return _vx;
}

float pacman::getVY(){
	return _vy;
}

float pacman::getSpeed(){
	return _speed;
}

float pacman::getAngle(){
	return _angle;
}

int pacman::getLives(){
	return _lives;
}

bool pacman::getAlive(){
	return _alive;
}

bool pacman::getDead(){
	return _dead;
}

void pacman::drawPacman(){
	
	glPushMatrix();
	
	if(_alive){

	GLfloat mat_specular[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_diffuse[] = {0.8, 0.8, 0.0, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(0.8, 0.8, 0.0);

	glTranslatef(_x, _y , 0.5f);
	glScalef(0.5f, 0.5f, 0.5f);
	glRotatef(90, 0.0f, 0.0f, 1.0f);
	glRotatef(_angle, 0.0f, .0f, 1.0f);
	glutSolidSphere(1.5f, 15.0f, 15.0f);
	drawEye(-.6f);
	drawEye(.6f);		
	drawEyeBrow(-.6f);
	drawEyeBrow(.6f);
	glEnd();
	}

	glPopMatrix();


}

void pacman::drawPacman(float x, float y){
	
	glPushMatrix();
	
	GLfloat mat_specular[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_diffuse[] = {0.8, 0.8, 0.0, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0};
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_specular);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_diffuse);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(0.8, 0.8, 0.0);

	glTranslatef(x, y , 0.5f);
	glScalef(0.5f, 0.5f, 0.5f);
	glRotatef(-90, 1.0f, 0.0f, 0.0f);
	glutSolidSphere(1.5f, 15.0f, 15.0f);
	drawEye(-.6f);
	drawEye(.6f);		
	drawEyeBrow(-.6f);
	drawEyeBrow(.6f);

	glPopMatrix();
	glEnd();

}

void pacman::drawEye(float x){
		
	glPushMatrix();

	GLfloat mat_SPECULAR[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_emission0[] = {0.0, 0.0, 0.0, 0.0 };
	GLfloat mat_emission1[] = {1.0, 1.0, 1.0, 1.0 };
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	if(!_radioactive){
		glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission0);}
	else{
		glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission1);}
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(1.0, 1.0, 1.0);

	glColor3f(1.0f, 1.0f, 1.0f);	
	glTranslatef(x, -1.28f, .5f);
	glutSolidSphere(.25f, 10.0f, 10.0f);
	drawSmallEye();

	glPopMatrix();

}

void pacman::drawSmallEye(void){

	glPushMatrix();

	GLfloat mat_SPECULAR[] = {1.0, 0.0, 0.0, 1.0 };
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(1.0, 0.0, 0.0);

	glColor3f(1.0f, 0.0f, 0.0f);
	glTranslatef(0.0f, -0.2f, 0.1f);
	glutSolidSphere(.1f, 6.0f, 6.0f);

	glPopMatrix();
}

void pacman::drawEyeBrow(float x){

	glPushMatrix();

	GLfloat mat_SPECULAR[] = {0.2, 0.2, 0.2, 1.0 };
	GLfloat mat_emission[] = {0.0, 0.0, 0.0, 0.0 };
	GLfloat mat_shine = 100.0;

	glMaterialfv (GL_FRONT, GL_SPECULAR, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_DIFFUSE, mat_SPECULAR);
	glMaterialfv(GL_FRONT, GL_EMISSION, mat_emission);
	glMaterialf (GL_FRONT, GL_SHININESS, mat_shine);

	glColor3f(0.2, 0.2, 0.2);

	glTranslatef(x, -0.94f, 1.f);	
	glScalef(.7f, 0.25f, .25f);
	glutSolidCube(1.0f);

	glPopMatrix();
}





