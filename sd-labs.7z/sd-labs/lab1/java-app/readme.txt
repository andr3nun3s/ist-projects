This is a (very) simple Java application

To compile:
javac *.java

To run:
java mypackage.MyClass arg0 arg1 arg2


Using Maven:
-----------

To compile:
mvn compile

To run:
mvn exec:java -Dexec.args="test 1 2 3"
    (-Dexec.mainClass="mypackage.MyClass" is not required because 
    the main class is being defined inside the POM)

To generate a launch script, for Windows and Unix:
mvn package appassembler:assemble

To run:
target\appassembler\bin\java-app test 1 2 3


To configure the project in Eclipse:
-----------------------------------

If Eclipse files (.project, .classpath) exist:
    'File', 'Import...', 'General'-'Existing Projects into Workspace'
    'Select root directory' and 'Browse' to the project base folder.
    Check if everything is OK and 'Finish'.

If Eclipse files do not exist:
    'File', 'Import...', 'Maven'-'Existing Maven Projects'.
    'Browse' to the project base folder.
    Check that the desired POM is selected and 'Finish'.

To run:
    Select the main class and click 'Run' (the green play button).
    Specify arguments using 'Run Configurations'

--
2015-01-23
Miguel.Pardal@tecnico.ulisboa.pt
