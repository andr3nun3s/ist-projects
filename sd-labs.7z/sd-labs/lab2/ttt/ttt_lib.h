#ifndef TTT_LIB_H
#define TTT_LIB_H

#define MAX_BUFFER_LEN 100


/* The board */
static char board[3][3] = {
    {'1','2','3'},  /* Initial values are reference numbers */
    {'4','5','6'},  /* used to select a vacant square for   */
    {'7','8','9'}   /* a turn.                              */
};


//////////////////////////////////////////
static char previous_board[3][3] = {
    {'1','2','3'},  /* Initial values are reference numbers */
    {'4','5','6'},  /* used to select a vacant square for   */
    {'7','8','9'}   /* a turn.                              */
};
///////////////////////////////////////////

void currentBoard(char *buffer);
int play(int row, int column, int player);
int checkWinner();

#endif
