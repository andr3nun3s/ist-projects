package ttt;

import java.rmi.registry.*;

public class Server {

	public static void main(String[] args) {
		int registryPort = 8081;
        try{
            TTT tttServer = new TTT();
            System.out.println("After create");
            
            Registry reg = LocateRegistry.createRegistry(registryPort);
			reg.rebind("TTTServer", tttServer);
           
            System.out.println("TTTServer server ready");
        }catch(Exception e) {
            System.out.println("TTTServer server main " + e.getMessage());
        }

	}

}
