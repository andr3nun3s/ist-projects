package ttt.client;

import java.net.MalformedURLException;
import java.rmi.*;
import java.util.Scanner;

import ttt.TTTService;

public class Client {
	TTTService ttt;
	Scanner keyboardSc;
	int winner = 0;
	int player = 1;

	public Client() {
		keyboardSc = new Scanner(System.in);
	}

	public int readPlay() {
		int play;
		do {
			System.out
					.printf("\nPlayer %d, please enter the number of the square "
							+ "where you want to place your %c (or 0 to refresh the board): \n",
							player, (player == 1) ? 'X' : 'O');
			play = keyboardSc.nextInt();
			if (play == 10) {
				return play;			
			}
		} while (play > 9 || play < 0);
		return play;
	}

	public void playGame() throws RemoteException {
		int play;
		boolean playAccepted;

		do {
			player = ++player % 2;
			do {
				System.out.println(ttt.currentBoard());
				play = readPlay();
				if (play != 0) {
					if (play == 10) {
						playAccepted = ttt.play(10, 10, player);
						player = 1;
					} else {
						playAccepted = ttt.play(--play / 3, play % 3, player);
					}
					if (!playAccepted)
						System.out.println("Invalid play! Try again.");
				} else
					playAccepted = false;
			} while (!playAccepted);
			winner = ttt.checkWinner();
		} while (winner == -1);
	}

	public void congratulate() throws RemoteException {
		if (winner == 2)
			System.out.printf("\nHow boring, it is a draw\n");
		else
			System.out.printf(
					"\nCongratulations, player %d, YOU ARE THE WINNER!\n",
					winner);
		ttt.resetGame();
		
	}

	public static void main(String[] args) {
		Client g = new Client();
		try {
			g.ttt = (TTTService) Naming.lookup("//localhost:8081/TTTServer");
			System.out.println("Found server");
			
			while(true){
				g.playGame();
				g.congratulate();
			}
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NotBoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
