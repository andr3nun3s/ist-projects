#teste
# sd-labs
Criei este repositorio para ser mais facil fazer os labs em casa e depois sacar as cenas na RNL, basta fazer:

``git clone git@github.com:andre-nunes/sd-labs.git``

Não levem a mal, não sei se já mexeram em git ou não mas vou fazer copy-paste do que mandei aos meus colegas de ipm do ano passado (com os comandos actualizados):


#### How-to git *crash course*

#####RECOMENDO ESTE GUIA:

http://try.github.io/levels/1/challenges/1



BÁSICO DO BÁSICO



**Setup**:

Metam o vosso nome e o vosso email associado à conta no GitHUb

https://help.github.com/articles/set-up-git



Para clonar o repositório têm de criar chaves ssh que provem que são voces a queres aceder ao repositorio:

https://help.github.com/articles/generating-ssh-keys



*Clonar o repositório*:

Isto cria um repositório local onde podemos efectuar alterações.



``git@github.com:andre-nunes/sd-labs.git``



Para guardar as alteraçôes deve-se:



primeiro ver o que foi alterado desde o último commit

```git status ```





Quando se criam ficheiros novos é preciso adicionar à lista de ficheiros para commit:



```git add newfile.c```





Para fazer commit:



```git commit -a -m "mensagem de commit"``` 



Depois do commit no repositório local é preciso "empurrar" as mudanças para o repositório central no GitHub:

*mas antes é importante ver se o repositório central foi actualizado por alguém do grupo:*

```git pull origin```



Para empurrar as mudanças:

```git push origin master```



E é isto, para não terem de meter a password sempre que querem enviar as alterações para o github recomendo usar chaves ssh:



https://help.github.com/articles/generating-ssh-keys
